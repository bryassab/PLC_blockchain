package com.ortopedic.ortopedicWork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrtopedicWorkApplicationTests {

	@Test
	void contextLoads() {
	}

}
